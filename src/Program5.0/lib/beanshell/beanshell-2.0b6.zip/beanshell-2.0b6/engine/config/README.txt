
This must appear in the classpath under:

  META-INF/services/javax.script.ScriptEngineFactory


